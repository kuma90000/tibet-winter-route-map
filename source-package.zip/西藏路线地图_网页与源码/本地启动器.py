"""使用本机地址打开网页，避免 file:// 的底图或 Referer 限制。仅需 Python 3 标准库。"""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote
import webbrowser

folder = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(folder))
server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
url = f"http://127.0.0.1:{server.server_port}/" + quote("西藏冬季路线地图.html")
print("本地地图地址：", url)
print("服务仅监听本机。保持此窗口打开；按 Ctrl+C 退出。")
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
