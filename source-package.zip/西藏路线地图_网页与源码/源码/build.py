from pathlib import Path

here = Path(__file__).resolve().parent
html = (here / "页面模板.html").read_text(encoding="utf-8")
for token, filename in [("__STYLES__", "styles.css"), ("__ROUTE_DATA__", "路线数据.json"), ("__APP_SCRIPT__", "app.js"), ("__EDITORIAL_DATA__", "地点图文与照片.json")]:
    html = html.replace(token, (here / filename).read_text(encoding="utf-8"), 1)
output = here.parent / "西藏冬季路线地图.html"
output.write_text(html, encoding="utf-8")
print("已生成：", output)
