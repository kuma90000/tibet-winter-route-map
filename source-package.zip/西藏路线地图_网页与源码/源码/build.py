from pathlib import Path
import json

here = Path(__file__).resolve().parent
html = (here / "页面模板.html").read_text(encoding="utf-8")
for token, filename in [("__STYLES__", "styles.css"), ("__ROUTE_DATA__", "路线数据.json"), ("__APP_SCRIPT__", "app.js"), ("__EDITORIAL_DATA__", "地点图文与照片.json")]:
    html = html.replace(token, (here / filename).read_text(encoding="utf-8"), 1)
data = json.loads((here / "路线数据.json").read_text(encoding="utf-8"))
html = html.replace("__ROUTE_COUNT__", str(len(data["routes"])))
html = html.replace("__NEW_COUNT__", str(sum(r["code"].startswith("N") for r in data["routes"])))
output = here.parent / "西藏冬季路线地图.html"
output.write_text(html, encoding="utf-8")
print("已生成：", output)
