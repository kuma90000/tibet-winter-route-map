#!/usr/bin/env python3
"""Validate the 17-route winter research extension and immutable original records.

Run from any directory: python 源码/validate_data.py
Uses Python standard library only. Does not modify files.
"""
import csv
import datetime
import hashlib
import json
from pathlib import Path

BASELINE = {'originalPointIds': ['lhasa', 'lxa', 'potala', 'jokhang', 'shigatse', 'tashilhunpo', 'qushui', 'kambala', 'yamdrok', 'langkazi', 'karola', 'gyantse', 'lhatse', 'sangsang', 'saga', 'zhongba', 'paryang', 'hor', 'darchen', 'kailash', 'manas', 'rakshas', 'menshi', 'baer', 'shiquanhe', 'geji', 'gerze', 'dongcuo', 'nyima', 'dazecuo', 'selin', 'bangor', 'nagqu', 'damxung', 'namtso', 'zhada', 'tulin', 'guge', 'toling', 'pangong', 'choqen', 'zharinam', 'tangra', 'wenbu', 'nyingchi', 'lzy', 'milin', 'pai', 'sosong', 'namcha', 'canyon', 'serkhyem', 'lulang', 'tongmai', 'guxiang', 'bomi', 'ranwu', 'laigu', 'midui', 'galong', 'motuo', 'guoguo', 'basum', 'gongbo', 'mila', 'lang', 'gyaca', 'tsetang', 'yumbu', 'samye', 'qiongjie', 'cuomei', 'luozha', 'se', 'cuoyu', 'baima', 'kula', 'pumo', 'tingri', 'gyatsola', 'gawula', 'zhaxizong', 'rongbuk', 'everest', 'gyirong', 'dongga', 'zhegu', 'kaju', 'lozho', 'renlongba', 'zhuxi', 'langqiu'], 'originalRouteCount': 14, 'originalRouteSourceCount': 22, 'originalPointSourceCount': 43, 'fingerprints': {'routes': 'ea9452cb087cd99f11c484573ed1a56ae35a7364334756e3a191b81220979307', 'points': 'db6ec5822f38ea71b262fbfe9b0a659a21a805ae8388c3961d9e9945b30d6234', 'routeSources': 'baffa46c6d72d31b5f4c84d1ea632bff50ccdbc429a40274ada5620d34079c5a', 'editorial': 'd726fb8f00c0e2b97e9c98cfa3f42a380172d20f858ab72ee9d3703097b0519d', 'photos': 'cff4b81c0769dd5390f86beaf06b3423383cfb178468045ef5d10f218d325142', 'pointSources': '2902ad4d7feff5f41d434787b0b5c2a802de6b7d12bd97126322160c17bb7e44', 'routeMeta': 'a185e1ca0531a5b5bea2e430a7db696f724307dcb88fdacebedfbe8580cf7000', 'editorialMeta': '473160933810fc95100df7e34082ac3604120a275b95d2606f4ead5804dee841', 'pointSourceMeta': '74c517a46887cad10eef00a551b5dd334d7d934197b6c64d89e367e792a8a61e'}, 'newRouteIds': ['yadong-valley-loop', 'shannan-lebu-culture', 'lhasa-cranes-shannan'], 'newPointIds': ['phari', 'yadong', 'duoqing', 'jomolhari-view', 'yadong-valley', 'cuona', 'lebu', 'changzhu', 'linzhou', 'kazi-view']}

ROOT = Path(__file__).resolve().parent
read = lambda name: json.loads((ROOT / name).read_text(encoding="utf-8"))
D = read("路线数据.json")
E = read("地点图文与照片.json")
PS = read("地点资料来源.json")
def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
def check(condition, message):
    if not condition:
        raise AssertionError(message)
def preserved(value, name):
    check(digest(value) == BASELINE["fingerprints"][name], "Original data changed: " + name)

oldkeys = BASELINE["originalPointIds"]
preserved(D["routes"][:BASELINE["originalRouteCount"]], "routes")
preserved({k: D["points"][k] for k in oldkeys}, "points")
preserved(D["sources"][:BASELINE["originalRouteSourceCount"]], "routeSources")
preserved({k: E["points"][k] for k in oldkeys}, "editorial")
preserved(E["photos"], "photos")
preserved(PS["sources"][:BASELINE["originalPointSourceCount"]], "pointSources")
preserved({k: v for k, v in D["meta"].items() if k != "researchExtension"}, "routeMeta")
preserved({k: v for k, v in E.items() if k not in ("points", "photos", "researchExtension")}, "editorialMeta")
preserved({k: v for k, v in PS.items() if k not in ("sources", "researchExtension")}, "pointSourceMeta")
check(len(D["routes"]) == 17, "Expected 17 routes")
check(len(D["points"]) == 102, "Expected 102 points")
check(set(D["points"]) == set(E["points"]), "Every point needs editorial content")
check(len(E["photos"]) == 44, "Expected 44 original photos")
check(len({r["id"] for r in D["routes"]}) == 17, "Duplicate route IDs")
check(len({r["code"] for r in D["routes"]}) == 17, "Duplicate route codes")
sids = {s["id"] for s in D["sources"]}
check(len(sids) == len(D["sources"]), "Duplicate route source IDs")
check(len({s["id"] for s in PS["sources"]}) == len(PS["sources"]), "Duplicate point source IDs")
for source in D["sources"]:
    for field in ("id", "title", "date", "url", "scope"):
        check(field in source, "Source missing " + field + ": " + source.get("id", "?"))
    check(source["url"].startswith("https://"), "Source URL must use https")
for route in D["routes"]:
    for field in ("kept", "missed"):
        check(all(k in D["points"] for k in route[field]), route["id"] + " unresolved " + field)
    check(all(k in sids for k in route["refs"]), route["id"] + " unresolved source")
    for day in route["days"]:
        for field in ("keys", "highlights"):
            check(all(k in D["points"] for k in day[field]), route["id"] + " unresolved " + field)
        check(all(k in sids for k in day["refs"]), route["id"] + " day source missing")

nondriving = {"duoqing", "jomolhari-view", "yadong-valley", "kazi-view"}
newroutes = [r for r in D["routes"] if r["id"] in BASELINE["newRouteIds"]]
check(len(newroutes) == 3, "Three new route IDs must exist")
check(sum(len(r["days"]) for r in D["routes"]) == 163, "Expected 163 route days/segments")
new_days = 0
for route in newroutes:
    n = route["duration"]
    check(n == len(route["days"]) and n in (7, 12), route["id"] + " duration invalid")
    check(route["days"][-1]["sleep"] is None, route["id"] + " final day must not imply airport lodging")
    check(route["origin"] == route["days"][0]["start"] == "lxa", "Arrival endpoint mismatch")
    check(route["destination"] == route["days"][-1]["end"] == "lxa", "Departure endpoint mismatch")
    for field in ("km", "maxSleep", "highNights"):
        check(route["stats"][field] is None, route["id"] + " unknown aggregate rendered as known")
    check(route["stats"]["hours"] == [sum(d["hours"][i] for d in route["days"]) for i in (0, 1)], "Driving time sums mismatch")
    check(route["stats"]["roadDays"] == sum(d["tag"] == "公路" for d in route["days"]), "Road-day count mismatch")
    check(route["bufferDays"] == sum(d["buffer"] for d in route["days"]), "Buffer count mismatch")
    check(route["returnBufferDays"] == (1 if n == 12 else 0), "Return buffer count mismatch")
    for index, day in enumerate(route["days"], 1):
        new_days += 1
        check(day["day"] == index, "Day numbering mismatch")
        check(day["date"] == (datetime.date(2026, 12, 25) + datetime.timedelta(days=index - 1)).isoformat(), "Date sequence mismatch")
        check(day["start"] == day["keys"][0] and day["end"] == day["keys"][-1], "Daily endpoints mismatch")
        if index > 1:
            check(day["start"] == route["days"][index - 2]["end"], "Daily continuity mismatch")
        check(not (set(day["keys"]) & nondriving), "Lake/region/summit is a driving waypoint")
        for field in ("km", "sleepAlt", "sleepChange"):
            check(day[field] is None, "Unknown day field filled: " + field)
        check(day["profile"] == [], "Unverified profile must remain empty")
        check(len(day["hours"]) == 2 and 0 <= day["hours"][0] <= day["hours"][1], "Invalid time range")
        for field in ("title", "tag", "road", "note"):
            check(bool(day[field]), "Required display field empty: " + field)
    for day in route["days"][1:3]:
        check(day["start"] == day["end"] == day["sleep"] == "lhasa" and day["keys"] == ["lhasa"] and not day["buffer"] and day["tag"] == "市内", "Two full Lhasa days lost")
    filename = "西藏行程_{}_{}-{}.csv".format(route["code"], route["days"][0]["date"].replace("-", ""), route["days"][-1]["date"].replace("-", ""))
    with (ROOT.parent / "逐日行程CSV" / filename).open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    check(len(rows) == n, "CSV day count mismatch")
    for day, row in zip(route["days"], rows):
        check(row["日期"] == day["date"], "CSV date mismatch")
        for field in ("住宿海拔_约米", "较前夜变化_约米", "公路里程下限_km", "公路里程上限_km"):
            check(row[field] == "", "CSV unknown must be blank: " + field)
    check(rows[-1]["住宿"] == "", "CSV final day must not imply airport lodging")
check(new_days == 31, "Expected 31 new days")
allnewkeys = {k for r in newroutes for d in r["days"] for k in d["keys"] + d["highlights"]}
for key in BASELINE["newPointIds"]:
    point = D["points"][key]
    check(key in allnewkeys, "New point orphaned: " + key)
    check(-90 <= point["lat"] <= 90 and -180 <= point["lon"] <= 180, "Invalid coordinate")
    check(point["navigable"] is False, "Schematic point must not promise navigation")
    check(point["coordinateSystem"] == "WGS84 (OSM source)", "Coordinate system missing")
    check(point["coordinateAttribution"] and point["coordinateLicenseUrl"] == "https://www.openstreetmap.org/copyright", "Coordinate attribution missing")
    check(point["coordinatePrecision"]["accuracyMeters"] is None, "Unverified coordinate precision inferred")
    check(all(s in sids for s in point["refs"]), "Point source missing")
    check(E["points"][key]["photo"] is None and E["points"][key]["gallery"] == [], "Unlicensed new photo")
    check(bool(E["points"][key]["reading"]), "New point source reading missing")
for key in nondriving:
    check(D["points"][key]["remote"] is True, "Non-driving pin must be remote")

print(json.dumps({"status": "PASS", "routes": len(D["routes"]), "points": len(D["points"]), "editorialPoints": len(E["points"]), "daysAndSegments": sum(len(r["days"]) for r in D["routes"]), "originalRoutesPreserved": 14, "originalPointsPreserved": 92, "originalEditorialPreserved": 92, "originalPhotosPreserved": 44, "newDays": new_days, "newCsvFiles": 3, "routeSources": len(D["sources"]), "pointSources": len(PS["sources"]), "unknownFieldsPreserved": True, "nonDrivingCentroidsExcluded": True}, ensure_ascii=False, indent=2))
