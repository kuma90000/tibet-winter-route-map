'use strict';
/* Standalone planning map; original itinerary data retained unchanged.
   OSM is the default, viewport-only basemap. Official domestic SDKs load only on activation. */
const DATA=JSON.parse(document.getElementById('route-data').textContent);
const P=DATA.points, R=DATA.routes, $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n).toLocaleString('zh-CN',{maximumFractionDigits:1});
const range=(a,unit='')=>a[0]===a[1]?`${fmt(a[0])}${unit}`:`${fmt(a[0])}–${fmt(a[1])}${unit}`;
const shortDate=d=>{const [y,m,dd]=d.split('-');return `${Number(m)}/${Number(dd)}`};
const IC={
 fit:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',minus:'<path d="M5 12h14"/>',
 left:'<path d="m15 5-7 7 7 7"/>',right:'<path d="m9 5 7 7-7 7"/>',
 play:'<path d="m8 4 12 8-12 8Z"/>',pause:'<path d="M8 5v14M16 5v14"/>',
 close:'<path d="m6 6 12 12M6 18 18 6"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7v.5"/>',
 download:'<path d="M12 3v12m-5-5 5 5 5-5M4 15v6h16v-6"/>',
 layers:'<path d="m12 3 10 6-10 6L2 9Zm-9 11 9 5 9-5M3 18l9 5 9-5"/>',
 compare:'<path d="M3 4h7v16H3Zm11 0h7v16h-7M6 8h1m-1 4h1m-1 4h1m10-8h1m-1 4h1m-1 4h1"/>',
 chart:'<path d="M3 3v18h18M6 16l5-7 5 4 5-9"/>',
 peak:'<path d="M2 20 10 4l5 10 3-5 5 11ZM7 10l3 2 3-2"/>',
 lake:'<path d="M2 9q3-4 6 0t6 0 6 0M2 14q3-4 6 0t6 0 6 0M2 19q3-4 6 0t6 0 6 0"/>',
 glacier:'<path d="M12 2v20M3.3 7l17.4 10M3.3 17 20.7 7M9 4l3 3 3-3M9 20l3-3 3 3M4 10l4-1-1-4M17 19l-1-4 4-1M4 14l4 1-1 4M17 5l-1 4 4 1"/>',
 forest:'<path d="m12 2 7 9h-4l6 8H3l6-8H5ZM12 19v4"/>',
 heritage:'<path d="m2 8 10-6 10 6ZM4 11v8m5-8v8m6-8v8m5-8v8M2 22h20M2 19h20"/>',
 city:'<path d="M3 20v-9h18v9M3 15h18M6 11V5h12v6M5 20v2m14-2v2M9 5v6m6-6v6"/>',
 hike:'<circle cx="13" cy="3" r="2"/><path d="m9 9 4-3 3 6h4M12 7l-2 8-4 7m5-8 5 4v4M8 7 6 13m13 0v9"/>',
 pass:'<path d="m1 20 7-13 4 7 4-7 7 13M10 2h7l-2 2 2 2h-7M10 2v10"/>',
 landscape:'<path d="M2 21h21M4 21V9l3-5 3 5v12m3 0V5l3-3 3 3v16m0-10 3-3v13"/>',
 airport:'<path d="m2 12 8-2V4c0-3 4-3 4 0v6l8 2v3l-8-1v5l3 2v1l-5-1-5 1v-1l3-2v-5l-8 1Z"/>',
 arrow:'<path d="M3 12h18m-6-6 6 6-6 6"/>',
 check:'<path d="m4 12 5 5L20 6"/>',
 warning:'<path d="m12 3 10 18H2ZM12 9v5m0 3v.2"/>'
};
function icon(k,size=18){return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[k]||IC.city}</svg>`}
function fillIcons(root=document){root.querySelectorAll('[data-icon]').forEach(e=>{e.innerHTML=icon(e.dataset.icon)})}
const CATS={peak:{name:'雪山远观',color:'#527F91'},lake:{name:'湖泊',color:'#438A9B'},glacier:{name:'冰川',color:'#699DA8'},forest:{name:'森林峡谷',color:'#638359'},heritage:{name:'人文',color:'#A5824E'},hike:{name:'可选步行',color:'#A66E64'},city:{name:'住宿城镇',color:'#577163'},pass:{name:'山口',color:'#93906A'},airport:{name:'机场',color:'#7F8C8F'},landscape:{name:'土林地貌',color:'#AD7D56'}};
const state={route:R[0].id,day:null,filter:'all',mode:'single',checked:new Set(R.map(r=>r.id)),chart:'sleep',tab:'itinerary',highlight:true,labels:true,missed:false,hiddenCats:new Set(),online:true,basemap:'osm',playing:false};
const cam={x:0,y:0,z:6}, size={w:800,h:400};let popupKey=null,raf=0,playTimer=null,toastTimer=null,tileCount=0,tileFailures=0;
const route=()=>R.find(r=>r.id===state.route)||R[0];
const selectedDay=()=>state.day===null?null:route().days[state.day];
function refs(ids=[]){return ids.map(id=>`<button class="source-ref" data-source="${id}" title="查看参考来源 ${id}">${id}</button>`).join('')}
function notify(text){clearTimeout(toastTimer);$('toast').textContent=text;$('toast').classList.add('show');toastTimer=setTimeout(()=>$('toast').classList.remove('show'),3400)}
function routePoints(r){return [...new Set(r.days.flatMap(d=>d.keys))]}
function routeHighlights(r){return [...new Set(r.days.flatMap(d=>d.highlights))]}
function isVisibleRoute(r){return state.filter==='all'||(state.filter==='ali'?r.code.startsWith('A'):r.code.startsWith('L'))}
function visibleRoutes(){return state.mode==='compare'?R.filter(r=>state.checked.has(r.id)&&isVisibleRoute(r)):[route()]}
function saveHash(){try{const p=new URLSearchParams({route:state.route});if(state.day!==null)p.set('day',state.day+1);if(state.mode==='compare')p.set('mode','compare');history.replaceState(null,'','#'+p.toString())}catch(e){/* file previews may restrict history */}}
function updateTheme(){document.documentElement.style.setProperty('--accent',route().color);document.documentElement.style.setProperty('--accent-soft',route().color+'14')}
function renderRouteList(){let group='';$('routeList').innerHTML=R.filter(isVisibleRoute).map(r=>{
 const heading=group!==r.group?`<div class="route-group">${r.group==='阿里出行'?'WEST / 阿里出行':'EAST / 林芝进藏'}</div>`:'';group=r.group;
 return `${heading}<div class="route-card ${r.id===state.route?'active':''}" style="--rcolor:${r.color}" data-route="${r.id}" role="button" tabindex="0" aria-pressed="${r.id===state.route}"><div class="route-top"><span class="route-code">${r.code}</span><span class="route-name">${esc(r.name)}</span>${state.mode==='compare'?`<input type="checkbox" class="route-check" data-overlay="${r.id}" ${state.checked.has(r.id)?'checked':''} aria-label="对照显示 ${esc(r.name)}">`:'<span class="route-radio" aria-hidden="true"></span>'}</div><div class="route-sub">${esc(r.subtitle)}</div><div class="route-meta"><span><b>${r.stats.roadDays}</b> 个公路日</span><span>最高住宿 <b>${fmt(r.stats.maxSleep)}m</b></span></div></div>`
 }).join('');requestAnimationFrame(()=>{const list=$('routeList'),card=list.querySelector('.route-card.active');if(!card)return;const a=card.getBoundingClientRect(),b=list.getBoundingClientRect();if(innerWidth<=950){if(a.left<b.left||a.right>b.right)list.scrollLeft+=a.left-b.left-5;}else if(a.top<b.top||a.bottom>b.bottom){list.scrollTop+=a.top-b.top-7;}})}
function renderStats(){const r=route(),s=r.stats;$('routeEyebrow').textContent=`${r.code} / ${r.group==='阿里出行'?'WESTERN TIBET':'EASTERN TIBET'} · 12 DAYS`;$('routeTitle').textContent=r.name;$('routeSubtitle').textContent=r.subtitle;
 $('stats').innerHTML=[['计划公路里程',range(s.km), 'km','含接驳与市内粗估'],['净驾驶时长',range(s.hours),'h','不含吃饭、拍照与等候'],['最高住宿海拔',fmt(s.maxSleep),'m',`4500米及以上 ${s.highNights} 晚`],['末段条件缓冲',r.buffer?'1':'0','天',r.buffer?'占用时会减少拉萨游览':'1/4长途回城 · 次日航班']].map(([l,v,u,f])=>`<div class="stat"><div class="stat-label">${l}</div><div class="stat-value num">${v}<small>${u}</small></div><div class="stat-foot">${f}</div></div>`).join('')}
function chips(keys,missed=false){return `<div class="highlight-chips">${keys.map(k=>`<button class="highlight-chip" data-focus="${k}" title="在地图上查看${esc(P[k].name)}"${missed?' data-missed="true"':''}><span style="color:${CATS[P[k].kind].color}">${icon(P[k].kind,12)}</span>${esc(P[k].name)}</button>`).join('')}</div>`}
function renderRight(){const r=route(),d=selectedDay();$('rightHeading').textContent=state.tab==='itinerary'?'逐日行程':'取舍与约束';$('itineraryTab').classList.toggle('active',state.tab==='itinerary');$('tradeoffTab').classList.toggle('active',state.tab==='tradeoff');
 if(state.tab==='tradeoff'){
  $('rightContent').innerHTML=`<div class="trade-block"><div class="summary-eyebrow">${r.code} · 为什么这样走</div><h3>${esc(r.name)}</h3><p>${esc(r.tradeoff)}</p></div><div class="trade-block"><h3>${icon('check',15)} 本线保留</h3>${chips(r.kept)}</div><div class="trade-block"><h3>${icon('minus',15)} 本线未包含</h3><p>点击一个点，查看它与主线的空间关系。未包含点以灰色显示。</p>${chips(r.missed,true)}</div><div class="risk-box"><h3>冬季条件，不是已确认放行</h3><p>${esc(r.risk)}</p></div><div class="trade-block" style="margin-top:18px"><h3>路线类型提醒</h3><p>${r.id==='ali-south'?'这条是南线往返，不是大环线。':r.code.startsWith('A')?'这里走G317主干道，不等于经过中北线的全部湖泊。':r.id==='linzhi-motuo'?'本方案沿波墨公路进出；不采用尚未核实的派墨直通。':r.id==='linzhi-shannan'?'白玛林措是库拉岗日周边的可选步行，不是冈仁波齐转山。':'林芝方案含必要折返；不能因地图直线距离短就按直线开车。'}</p></div><p style="font-size:10px;color:var(--muted)">参考：${refs(r.refs)}</p>`;fillIcons($('rightContent'));return;
 }
 let top='';
 if(d){const start=P[d.start],end=P[d.end];const max=Math.max(...d.profile.map(v=>v[1]));const delta=d.sleepChange===null?'—':`${d.sleepChange>0?'+':''}${fmt(d.sleepChange)} m`;
  top=`<article class="day-detail"><div class="day-date"><span>DAY ${String(d.day).padStart(2,'0')} / ${d.date}</span><span>${esc(d.tag)}</span></div><h3>${esc(d.title)}</h3><div class="city-pair"><div class="place">起点<b>${esc(start.name)}</b><span>约 ${fmt(start.alt)} m</span></div><span class="arr">→</span><div class="place">终点<b>${esc(end.name)}</b><span>约 ${fmt(end.alt)} m</span></div></div><div class="day-stats"><div class="day-stat"><small>公路里程估计</small><strong>${range(d.km)} <small style="display:inline">km</small></strong></div><div class="day-stat"><small>净驾驶时间</small><strong>${range(d.hours)} <small style="display:inline">h</small></strong></div><div class="day-stat"><small>当晚住宿海拔</small><strong>${d.sleep?fmt(d.sleepAlt)+' m':'离藏 · 不计住宿'}</strong></div><div class="day-stat"><small>较前夜住宿变化</small><strong>${delta}</strong></div></div>${d.walk?`<div class="inline-note">另留步行／景区活动 ${range(d.walk)} 小时；不含在驾驶时间中。</div>`:''}<p class="day-note">${esc(d.note)} ${refs(d.refs)}</p><div class="road-label">${esc(d.road||'机场接驳／市内活动')}<br>已标注关键点最高约 ${fmt(max)} m，非全路段最高海拔。</div>${chips(d.highlights)}</article>`;
 }else{
  top=`<div class="route-summary"><div class="summary-eyebrow">路线总览 · ${r.stats.roadDays} 个公路日</div><h3>${r.group==='阿里出行'?'拉萨出发，拉萨结束。':'林芝进入，拉萨离开。'}</h3><p>${esc(r.tradeoff)}</p><div class="mini-facts"><span class="mini-fact">12 天 / 11 晚</span><span class="mini-fact">${r.stats.highNights} 晚 ≥4500m</span><span class="mini-fact ${r.buffer?'':'warn'}">${r.buffer?'末段可腾出 1 天':'无末段缓冲'}</span></div></div>`;
 }
 $('rightContent').innerHTML=top+`<div class="section-label"><span>12天安排 · 点击联动地图</span>${d?'<button id="backAll">回到总览</button>':''}</div><div class="itinerary">${r.days.map((v,i)=>`<button class="day-row ${state.day===i?'selected':''}" data-day="${i}" aria-label="第${i+1}天 ${esc(v.title)}"><div class="day-dot"><b>D${i+1}</b><small>${shortDate(v.date)}</small></div><div class="day-content"><b>${esc(v.title)}</b><div class="row-meta"><span class="row-sleep">${v.sleep?`${esc(P[v.sleep].name)} · ${fmt(v.sleepAlt)}m`:'离藏，无住宿海拔'}</span><span class="num">${range(v.hours)}h</span></div></div><span class="row-right">›</span></button>`).join('')}</div>`;
}
function renderDayStrip(){$('dayStrip').innerHTML=route().days.map((d,i)=>`<button class="day-pill ${state.day===i?'active':''}" data-day="${i}" aria-label="第${d.day}天，${d.date}，${esc(d.title)}" title="${esc(d.title)} · 行车 ${range(d.hours)}h"><span class="d">D${d.day}</span><span class="dt">${shortDate(d.date)}</span><span class="timebar"><i style="width:${Math.min(100,((d.hours[0]+d.hours[1])/2)/9*100)}%"></i></span></button>`).join('');$('prevDay').disabled=state.day===0;$('nextDay').disabled=state.day===11;updatePlayIcon()}
function renderLegend(){$('legend').innerHTML=Object.entries(CATS).filter(([k])=>!['airport','pass'].includes(k)).map(([k,c])=>`<button class="legend-btn ${state.hiddenCats.has(k)?'off':''}" data-cat="${k}" title="显示／隐藏${c.name}" aria-pressed="${!state.hiddenCats.has(k)}"><span class="legend-icon" style="color:${c.color}">${icon(k,14)}</span>${c.name}</button>`).join('')}
function selectRoute(id){if(!R.some(r=>r.id===id))return;stopPlay();state.route=id;state.day=null;popupKey=null;hidePopup();state.tab='itinerary';if(state.mode==='compare')state.checked.add(id);updateAll(true);saveHash();$('liveStatus').textContent='已选择 '+route().name}
function selectDay(i,fromPlay=false){if(i<0||i>11)return;if(!fromPlay)stopPlay();state.day=i;state.tab='itinerary';if(state.chart==='sleep')state.chart='daily';popupKey=null;hidePopup();renderRight();renderDayStrip();renderChart();renderMapHeader();fitCurrent();saveHash();$('liveStatus').textContent=`第${i+1}天，${selectedDay().title}，净驾驶${range(selectedDay().hours)}小时`;const b=$('dayStrip').querySelector(`[data-day="${i}"]`);if(b){const cont=$('dayStrip');if(b.offsetLeft<cont.scrollLeft||b.offsetLeft+b.offsetWidth>cont.scrollLeft+cont.clientWidth)cont.scrollLeft=b.offsetLeft-cont.clientWidth/2+b.offsetWidth/2} }
function overview(){stopPlay();state.day=null;popupKey=null;hidePopup();state.chart='sleep';updateAll(true);saveHash()}
function renderMapHeader(){const d=selectedDay();$('mapStatus').textContent=d?`D${d.day} · ${esc(P[d.start].name)} → ${esc(P[d.end].name)}`:state.mode==='compare'?`${visibleRoutes().length} 条路线对照`:'整条路线 · 起点 / 终点';$('overviewBtn').classList.toggle('active',state.day===null);$('singleMode').classList.toggle('active',state.mode==='single');$('compareMode').classList.toggle('active',state.mode==='compare');$('compareLegend').classList.toggle('hidden',state.mode!=='compare');$('compareLegend').innerHTML=visibleRoutes().map(r=>`<button data-route="${r.id}" title="选择${esc(r.name)}"><i style="background:${r.color}"></i>${r.code} ${r.name.split(' · ')[1]||r.name.replace('林芝 → ','')}</button>`).join('')}
function updateAll(fit=false){updateTheme();renderRouteList();renderStats();renderRight();renderDayStrip();renderLegend();renderMapHeader();renderChart();if(fit)fitCurrent();else requestMap()}

/* Runs in a fresh frame per activation, so changed credentials never reuse an old SDK. */
function officialMapFrame(config) {
  'use strict';
  const isAMap = config.provider === 'amap';
  const send = (type, extra = {}) => parent.postMessage({channel: 'tibet-map-v1', token: config.token, type, ...extra}, '*');
  const entries = Object.entries(config.points);
  let map, converted = {}, lastProjection = '', ready = false;
  const deadline = (start, label, ms = 18000) => new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(label)), ms);
    start(value => {clearTimeout(timer); resolve(value);}, error => {clearTimeout(timer); reject(error);});
  });
  function loadSDK() {
    return deadline((resolve, reject) => {
      const script = document.createElement('script');
      script.onerror = () => reject(new Error('地图脚本未能加载，请检查网络。'));
      window.sdkReady = () => resolve();
      if (isAMap) {
        // Must precede the official JS API script, as required by AMap.
        window._AMapSecurityConfig = {securityJsCode: config.security};
        script.src = 'https://webapi.amap.com/maps?v=2.0&key=' + encodeURIComponent(config.key) + '&callback=sdkReady';
      } else {
        script.src = 'https://api.map.baidu.com/api?v=4.0&ak=' + encodeURIComponent(config.key) + '&callback=sdkReady';
      }
      document.head.appendChild(script);
    }, '地图脚本加载超时；请核对 Key 类型、域名授权及网络。', 22000);
  }
  async function convertCoordinates() {
    // Official services only. Never draw unconverted WGS84 on a domestic basemap.
    const batchSize = isAMap ? 40 : 10;
    for (let offset = 0; offset < entries.length; offset += batchSize) {
      const batch = entries.slice(offset, offset + batchSize);
      const locations = await deadline((resolve, reject) => {
        if (isAMap) {
          AMap.convertFrom(batch.map(([, p]) => [p.lon, p.lat]), 'gps', (status, result) => {
            if (status === 'complete' && result?.locations?.length === batch.length) resolve(result.locations);
            else reject(new Error('高德坐标转换失败；请检查 Key、安全密钥、授权或配额。'));
          });
        } else {
          new BMap.Convertor().translate(batch.map(([, p]) => new BMap.Point(p.lon, p.lat)), 1, 5, result => {
            if (result?.status === 0 && result.points?.length === batch.length) resolve(result.points);
            else reject(new Error('百度坐标转换失败；请检查浏览器端 AK、服务权限或配额。'));
          });
        }
      }, '官方坐标转换超时；已停止绘制，以免标记偏移。');
      batch.forEach(([key], i) => { converted[key] = locations[i]; });
      send('progress', {text: '正在校准景点位置 ' + Math.min(offset + batchSize, entries.length) + '/' + entries.length});
    }
  }
  function fit(keys) {
    const points = [...new Set(keys)].map(key => converted[key]).filter(Boolean);
    if (!points.length) return;
    const pad = innerWidth < 450 ? 48 : 68;
    if (isAMap) {
      const lngs = points.map(p => p.getLng()), lats = points.map(p => p.getLat());
      const bounds = new AMap.Bounds([Math.min(...lngs) - .015, Math.min(...lats) - .015], [Math.max(...lngs) + .015, Math.max(...lats) + .015]);
      map.setBounds(bounds, true, [74, pad, 130, pad]);
      if (map.getZoom() > 11) map.setZoom(11, true);
    } else {
      // Give a single location a small extent rather than zooming to street level.
      const lngs = points.map(p => p.lng), lats = points.map(p => p.lat);
      map.setViewport([new BMap.Point(Math.min(...lngs) - .015, Math.min(...lats) - .015), new BMap.Point(Math.max(...lngs) + .015, Math.max(...lats) + .015)], {margins: [74, pad, 130, pad], enableAnimation: false});
      if (map.getZoom() > 11) map.setZoom(11, {noAnimation: true});
    }
  }
  function projection() {
    if (!ready) return;
    try {
      const pixels = {};
      for (const [key] of entries) {
        const pixel = isAMap ? map.lngLatToContainer(converted[key]) : map.pointToPixel(converted[key]);
        const x = isAMap ? pixel.getX() : pixel.x, y = isAMap ? pixel.getY() : pixel.y;
        if (!Number.isFinite(x) || !Number.isFinite(y)) return;
        pixels[key] = [Math.round(x * 10) / 10, Math.round(y * 10) / 10];
      }
      const center = map.getCenter(), lat = isAMap ? center.getLat() : center.lat;
      const text = JSON.stringify(pixels);
      if (text !== lastProjection) {
        lastProjection = text;
        const left = isAMap ? map.containerToLngLat(new AMap.Pixel(0, innerHeight / 2)) : map.pixelToPoint(new BMap.Pixel(0, innerHeight / 2));
        const right = isAMap ? map.containerToLngLat(new AMap.Pixel(70, innerHeight / 2)) : map.pixelToPoint(new BMap.Pixel(70, innerHeight / 2));
        const mpp = (isAMap ? left.distance(right) : map.getDistance(left, right)) / 70;
        send('projection', {pixels, zoom: map.getZoom(), lat, mpp, width: innerWidth, height: innerHeight});
      }
    } catch (_) { /* Map resize and first render may briefly lack a projection. */ }
  }
  // Sampling official screen coordinates also tracks SDK animations and touch gestures.
  function tick() {projection(); requestAnimationFrame(tick);}
  window.addEventListener('message', event => {
    const message = event.data;
    if (event.source !== parent || message?.channel !== 'tibet-map-v1' || message.token !== config.token || !ready) return;
    if (message.type === 'fit') fit(message.keys);
    if (message.type === 'zoom') {
      const zoom = Math.max(4, Math.min(13, map.getZoom() + (message.delta > 0 ? 1 : -1)));
      if (isAMap) map.setZoom(zoom, true); else map.setZoom(zoom, {noAnimation: true});
    }
    if (message.type === 'focus' && converted[message.key]) {
      const zoom = Math.min(10, Math.max(map.getZoom(), 8));
      if (isAMap) map.setZoomAndCenter(zoom, converted[message.key], true);
      else map.centerAndZoom(converted[message.key], zoom);
    }
    lastProjection = ''; projection();
  });
  (async () => {
    try {
      await loadSDK();
      if (isAMap ? !window.AMap?.Map : !window.BMap?.Map) throw new Error('地图 SDK 未就绪；请核对浏览器端 Key 和服务授权。');
      await convertCoordinates();
      const center = converted.lhasa || converted[entries[0][0]];
      if (isAMap) {
        map = new AMap.Map('map', {center, zoom: 6, viewMode: '2D', pitch: 0, rotation: 0, rotateEnable: false, pitchEnable: false, keyboardEnable: false, resizeEnable: true, animateEnable: false, zooms: [4, 13]});
      } else {
        map = new BMap.Map('map', {enableRotate: false, enableTilt: false, enableRotateGestures: false, enableTiltGestures: false, enableKeyboard: false, enableAutoResize: true, minZoom: 4, maxZoom: 13});
        map.centerAndZoom(center, 6);
        map.enableScrollWheelZoom();
      }
      await deadline((resolve) => {
        if (isAMap) map.on('complete', resolve);
        else {map.addEventListener('tilesloaded', resolve); map.addEventListener('firsttileload', resolve);}
      }, '地图底图加载超时；请检查 Key、域名授权和地图网络。', 18000);
      ready = true;
      fit(config.fitKeys);
      if (isAMap) map.on('click', () => send('mapClick'));
      else map.addEventListener('click', () => send('mapClick'));
      projection(); send('ready'); tick();
    } catch (error) {
      send('error', {text: error.message || '地图服务暂不可用，请检查设置。'});
    }
  })();
}

// Map settings affect only the basemap; all original itinerary data stays intact.
const BASEMAP_NAMES = {schematic: '离线示意底图', osm: 'OpenStreetMap', amap: '高德地图', baidu: '百度地图'};
const MAP_STORAGE = 'tibet-route-map-settings-v1';
const credentials = {amapKey: '', amapSecurity: '', baiduKey: ''};
let sdkFrame = null, sdkToken = '', sdkTimeout = null, sdkPixels = {}, sdkScale = null;
let pendingProvider = null, settingsChoice = 'osm', storedSettings = false;
const isOfficialMap = () => state.basemap === 'amap' || state.basemap === 'baidu';
function currentFitKeys() {
  const d = selectedDay();
  const keys = d ? [...d.keys, ...(state.highlight ? d.highlights : [])] : visibleRoutes().flatMap(r => [...routePoints(r), ...(state.highlight ? routeHighlights(r) : [])]);
  if (state.missed) keys.push(...route().missed);
  return keys;
}
function mapNotice(text = '', error = false) {
  const el = $('mapServiceNotice');
  el.textContent = text;
  el.classList.toggle('hidden', !text);
  el.classList.toggle('service-error', error);
  $('settingsStatus').textContent = text;
}
function refreshProviderUI() {
  $('basemapSelect').value = pendingProvider || state.basemap;
  $('basemapLabel').textContent = pendingProvider ? '加载中' : BASEMAP_NAMES[state.basemap];
  $('mapPanel').classList.toggle('sdk-active', isOfficialMap());
}
function sendSDK(type, extra = {}) {
  if (sdkFrame && isOfficialMap()) sdkFrame.contentWindow.postMessage({channel: 'tibet-map-v1', token: sdkToken, type, ...extra}, '*');
}
function removeSDK() {
  clearTimeout(sdkTimeout);
  sdkTimeout = null;
  sdkFrame?.remove(); sdkFrame = null; sdkToken = '';
  sdkPixels = {}; sdkScale = null; pendingProvider = null;
}
function settingsValues() {
  return {amapKey: $('amapKey').value.trim(), amapSecurity: $('amapSecurity').value.trim(), baiduKey: $('baiduKey').value.trim()};
}
function saveMapSettings() {
  Object.assign(credentials, settingsValues());
  const remember = $('rememberKeys').checked;
  try {
    if (remember) localStorage.setItem(MAP_STORAGE, JSON.stringify(credentials));
    else localStorage.removeItem(MAP_STORAGE);
    storedSettings = remember;
  } catch (_) {
    storedSettings = false;
    $('rememberKeys').checked = false;
    notify('浏览器不允许本地保存；Key 仍可在当前页面使用。');
  }
}
function openMapSettings(provider = pendingProvider || state.basemap) {
  settingsChoice = provider;
  document.querySelectorAll('[name="mapProvider"]').forEach(el => {el.checked = el.value === provider;});
  $('amapKey').value = credentials.amapKey;
  $('amapSecurity').value = credentials.amapSecurity;
  $('baiduKey').value = credentials.baiduKey;
  $('rememberKeys').checked = storedSettings;
  if (!$('mapSettingsDialog').open) $('mapSettingsDialog').showModal();
}
function activateBasemap(provider) {
  if (!Object.hasOwn(BASEMAP_NAMES, provider)) return;
  if ((provider === 'amap' && !credentials.amapKey) || (provider === 'baidu' && !credentials.baiduKey)) {
    openMapSettings(provider);
    $('settingsStatus').textContent = '请粘贴自己的浏览器端 Key 后启用；默认 OpenStreetMap 无需 Key。';
    refreshProviderUI(); return;
  }
  stopPlay(); hidePopup(); removeSDK();
  tileWarned = false; tileCount = 0; tileFailures = 0;
  $('tiles').innerHTML = ''; tileNodes.clear();
  if (provider === 'schematic' || provider === 'osm') {
    state.basemap = provider; state.online = provider === 'osm';
    refreshProviderUI(); mapNotice(); fitCurrent();
    if (provider === 'osm') scheduleOSMCheck();
    return;
  }
  // Keep the offline map interactive until both tiles and official conversion are ready.
  state.basemap = 'schematic'; state.online = false; pendingProvider = provider;
  refreshProviderUI(); requestMap();
  mapNotice('正在加载' + BASEMAP_NAMES[provider] + '，并通过官方服务校准位置；路线仍可操作。');
  const token = 'map-' + Date.now() + '-' + Math.random().toString(36).slice(2);
  sdkToken = token;
  const config = {provider, token, key: provider === 'amap' ? credentials.amapKey : credentials.baiduKey, security: credentials.amapSecurity, points: Object.fromEntries(Object.entries(P).map(([key, p]) => [key, {lon: p.lon, lat: p.lat}])), fitKeys: currentFitKeys()};
  const json = JSON.stringify(config).replace(/</g, '\\u003c');
  sdkFrame = document.createElement('iframe');
  sdkFrame.className = 'official-map-frame loading';
  sdkFrame.title = BASEMAP_NAMES[provider] + '官方交互地图';
  sdkFrame.referrerPolicy = 'strict-origin-when-cross-origin';
  sdkFrame.srcdoc = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body,#map{margin:0;width:100%;height:100%;overflow:hidden;background:#edf0e6}</style></head><body><div id="map"></div><script>(' + officialMapFrame.toString() + ')(' + json + ');<' + '/script></body></html>';
  $('mapStage').prepend(sdkFrame);
  sdkTimeout = setTimeout(() => {
    if (sdkToken === token && pendingProvider) mapFailed('加载超时，请检查 Key、服务授权、域名白名单或网络。');
  }, 55000);
}
function mapFailed(reason) {
  const provider = pendingProvider || state.basemap;
  removeSDK(); state.basemap = 'schematic'; state.online = false;
  refreshProviderUI(); fitCurrent();
  mapNotice(BASEMAP_NAMES[provider] + '未启用：' + reason + ' 当前使用离线示意底图，可从设置切回 OpenStreetMap。', true);
}
window.addEventListener('message', event => {
  const message = event.data;
  if (!sdkFrame || event.source !== sdkFrame.contentWindow || message?.channel !== 'tibet-map-v1' || message.token !== sdkToken) return;
  if (message.type === 'error') {mapFailed(String(message.text || '地图服务不可用。')); return;}
  if (message.type === 'progress' && pendingProvider) mapNotice(BASEMAP_NAMES[pendingProvider] + ' · ' + message.text);
  if (message.type === 'projection') {
    if (!message.pixels || Object.keys(P).some(k => !Array.isArray(message.pixels[k]) || message.pixels[k].length !== 2 || !message.pixels[k].every(Number.isFinite))) return;
    sdkPixels = message.pixels;
    sdkScale = {zoom: message.zoom, lat: message.lat, mpp: message.mpp};
    if (isOfficialMap()) requestMap();
  }
  if (message.type === 'ready' && pendingProvider) {
    clearTimeout(sdkTimeout); state.basemap = pendingProvider; pendingProvider = null; state.online = false;
    sdkFrame.classList.remove('loading'); refreshProviderUI();
    mapNotice(BASEMAP_NAMES[state.basemap] + '已启用 · 景点与路线已完成官方坐标转换；线路仍是经由点示意。');
    // Apply the latest selection even if the user changed days while the SDK loaded.
    sendSDK('fit', {keys: currentFitKeys()}); requestMap();
  }
  if (message.type === 'mapClick') hidePopup();
});
let osmCheckTimer;
function scheduleOSMCheck() {
  clearTimeout(osmCheckTimer);
  osmCheckTimer = setTimeout(() => {
    if (state.basemap === 'osm' && tileCount === 0) fallbackOSM();
  }, 10000);
}
function fallbackOSM() {
  if (state.basemap !== 'osm') return;
  activateBasemap('schematic');
  mapNotice('OpenStreetMap 底图暂不可用，已切回离线示意底图。可在设置中重试；直接打开 HTML 若受限制，请使用源码包内的本地启动器。', true);
}
function initializeMapSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem(MAP_STORAGE) || 'null');
    if (saved && ['amapKey', 'amapSecurity', 'baiduKey'].every(k => typeof saved[k] === 'string')) {Object.assign(credentials, saved); storedSettings = true;}
  } catch (_) { /* Private browsing and file previews may disable storage. */ }
  $('mapSettingsBtn').onclick = () => openMapSettings();
  $('basemapBtn').onclick = () => openMapSettings();
  $('basemapSelect').onchange = event => activateBasemap(event.target.value);
  document.querySelectorAll('[name="mapProvider"]').forEach(el => {el.onchange = () => {settingsChoice = el.value;};});
  $('applyMapSettings').onclick = () => {
    const values = settingsValues();
    const field = settingsChoice === 'amap' ? 'amapKey' : settingsChoice === 'baidu' ? 'baiduKey' : null;
    if (field && !values[field]) {$('settingsStatus').textContent = '请先填写对应的 Key；也可选择无需 Key 的 OpenStreetMap。'; $(field).focus(); return;}
    saveMapSettings(); $('mapSettingsDialog').close(); activateBasemap(settingsChoice);
  };
  $('clearMapKeys').onclick = () => {
    Object.keys(credentials).forEach(k => {credentials[k] = ''; $(k).value = '';});
    try {localStorage.removeItem(MAP_STORAGE);} catch (_) {}
    storedSettings = false; $('rememberKeys').checked = false;
    activateBasemap('osm'); settingsChoice = 'osm';
    document.querySelectorAll('[name="mapProvider"]').forEach(el => {el.checked = el.value === 'osm';});
    $('settingsStatus').textContent = 'Key 已清除，已切换到无需 Key 的 OpenStreetMap。';
  };
  $('mapSettingsDialog').addEventListener('close', () => {refreshProviderUI();});
  window.addEventListener('offline', () => {
    if (pendingProvider || isOfficialMap()) mapFailed('网络已断开。');
    else if (state.basemap === 'osm') fallbackOSM();
  });
  refreshProviderUI(); scheduleOSMCheck();
}

// Mercator geography. Each route line intentionally follows named planning waypoints only.
function merc(lon,lat){const s=Math.sin(Math.max(-80,Math.min(80,lat))*Math.PI/180);return [(lon+180)/360,.5-Math.log((1+s)/(1-s))/(4*Math.PI)]}
function inv(x,y){return [x*360-180,Math.atan(Math.sinh(Math.PI*(1-2*y)))*180/Math.PI]}
function world(){return 256*Math.pow(2,cam.z)}
function xy(k){if(isOfficialMap())return typeof k==='string'?(sdkPixels[k]||[-100000,-100000]):[-100000,-100000];const p=typeof k==='string'?P[k]:k,q=merc(p.lon,p.lat),s=world();return [(q[0]-cam.x)*s+size.w/2,(q[1]-cam.y)*s+size.h/2]}
function fitKeys(keys){if(isOfficialMap()){sendSDK('fit',{keys});return}const unique=[...new Set(keys)].filter(k=>P[k]);if(!unique.length){requestMap();return}const pts=unique.map(k=>merc(P[k].lon,P[k].lat));let minx=Math.min(...pts.map(p=>p[0])),maxx=Math.max(...pts.map(p=>p[0])),miny=Math.min(...pts.map(p=>p[1])),maxy=Math.max(...pts.map(p=>p[1]));const dx=Math.max(maxx-minx,.0005),dy=Math.max(maxy-miny,.0005),padx=size.w<450?48:68,padt=74,padb=100;const s=Math.min(Math.max(100,size.w-2*padx)/dx,Math.max(100,size.h-padt-padb)/dy);cam.z=Math.max(4,Math.min(11,Math.log2(s/256)));cam.x=(minx+maxx)/2;cam.y=(miny+maxy)/2+(padb-padt)/2/world();requestMap()}
function fitCurrent(){const d=selectedDay();let keys=d?[...d.keys,...(state.highlight?d.highlights:[])]:visibleRoutes().flatMap(r=>[...routePoints(r),...(state.highlight?routeHighlights(r):[])]);if(state.missed)keys.push(...route().missed);fitKeys(keys)}
function zoomBy(v,anchor=null){if(isOfficialMap()){sendSDK('zoom',{delta:v});return}const old=world(),nx=anchor?cam.x+(anchor[0]-size.w/2)/old:cam.x,ny=anchor?cam.y+(anchor[1]-size.h/2)/old:cam.y;cam.z=Math.max(4,Math.min(13,cam.z+v));if(anchor){const nw=world();cam.x=nx-(anchor[0]-size.w/2)/nw;cam.y=ny-(anchor[1]-size.h/2)/nw}requestMap()}
function pathFor(keys){return keys.map((k,i)=>{const a=xy(k);return `${i?'L':'M'}${a[0].toFixed(1)},${a[1].toFixed(1)}`}).join(' ')}
function visibleAt(a,pad=40){return a[0]>-pad&&a[0]<size.w+pad&&a[1]>-pad&&a[1]<size.h+pad}
function requestMap(){if(raf)return;raf=requestAnimationFrame(()=>{raf=0;renderMap()})}
function renderGrid(){const [west,north]=inv(cam.x-size.w/2/world(),cam.y-size.h/2/world()),[east,south]=inv(cam.x+size.w/2/world(),cam.y+size.h/2/world());const span=east-west;const step=span>15?5:span>7?2:span>3?1:span>1.3?.5:span>.5?.2:.1;let out='';
 for(let lon=Math.ceil(west/step)*step;lon<=east;lon+=step){const [x]=xy({lon,lat:0});out+=`<path d="M${x.toFixed(1)} 0V${size.h}" stroke="#d5dfd0" stroke-opacity=".62" stroke-width=".8"/><text x="${(x+5).toFixed(1)}" y="${size.h-4}" fill="#9aab98" font-size="8" font-family="var(--sans)">${fmt(lon)}°E</text>`}
 for(let lat=Math.ceil(south/step)*step;lat<=north;lat+=step){const [,y]=xy({lon:0,lat});out+=`<path d="M0 ${y.toFixed(1)}H${size.w}" stroke="#d5dfd0" stroke-opacity=".62" stroke-width=".8"/><text x="5" y="${(y-5).toFixed(1)}" fill="#9aab98" font-size="8" font-family="var(--sans)">${fmt(lat)}°N</text>`}return out}
function renderRegions(){const reg=[['阿 里',80.6,32.1,'NGARI'],['羌 塘 高 原',86.4,32.45,'CHANGTANG'],['藏 东 南',95.75,30.40,'SOUTHEAST TIBET'],['山 南',91.65,28.6,'LHOKHA'],['喜 马 拉 雅 山 脉',86.0,28.1,'HIMALAYA']];return reg.map(([n,lon,lat,en])=>{const [x,y]=xy({lon,lat});if(!visibleAt([x,y],180)||cam.z>9)return '';return `<text x="${x}" y="${y}" text-anchor="middle" class="map-region">${n}</text><text x="${x}" y="${y+20}" text-anchor="middle" class="map-region-sub">${en}</text>`}).join('')}
function markerShape(kind,color,missed){let body=IC[kind]||IC.city;return `<circle class="point-circle" r="11.5" fill="${missed?'#f6f7ef':'#fffefa'}" stroke="${missed?'#aebaaa':color}" stroke-width="1.4" ${missed?'stroke-dasharray="2 2"':''}/><g transform="translate(-7,-7) scale(.5833)" fill="none" stroke="${missed?'#9aa992':color}" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${body}</g>`}
function drawPoints(){const r=route(),d=selectedDay();let citykeys=visibleRoutes().flatMap(q=>routePoints(q));let hkeys=state.highlight?visibleRoutes().flatMap(q=>routeHighlights(q)):[];if(d)hkeys=state.highlight?[...routeHighlights(r)]:[];let missed=state.missed?r.missed:[];const keys=[...new Set([...citykeys,...hkeys,...missed])];const activeKeys=new Set(d?[...d.keys,...d.highlights]:[...routePoints(r),...routeHighlights(r)]);const allRouteKeys=new Set(visibleRoutes().flatMap(q=>[...routePoints(q),...routeHighlights(q)]));const placement=[];let shapes='',primaryShapes='',labels='';
 const start=d?d.start:(r.code.startsWith('A')?'lhasa':'nyingchi'),end=d?d.end:'lhasa';
 // Draw main cities last so their labels win over optional landmarks.
 keys.sort((a,b)=>{const sc=k=>(k===start||k===end)?10:(P[k].kind==='city'?7:P[k].remote?6:4)+(activeKeys.has(k)?1:0);return sc(b)-sc(a)});
 const accepted=[];
 keys.forEach(k=>{const p=P[k],a=xy(k);if(!visibleAt(a,70))return;let isMissed=missed.includes(k)&&!allRouteKeys.has(k);if(state.hiddenCats.has(p.kind))return;if(!state.highlight&&!['city','airport'].includes(p.kind))return;const selected=activeKeys.has(k);let opacity=d&&!selected&&!isMissed?.25:state.mode==='compare'&&!selected?.75:1;const primary=k===start||k===end;const cls=CATS[p.kind]||CATS.city;
 let shape='';if(primary){const t=start===end?'起 / 终':k===start?'起':'终';const w=start===end?40:26;shape=`<rect x="${-w/2}" y="-13" width="${w}" height="26" rx="9" fill="${r.color}" stroke="#fffefa" stroke-width="2"/><text text-anchor="middle" y="3.5" font-size="10" font-weight="700" fill="white" font-family="var(--sans)">${t}</text>`}
 else if(p.kind==='city'||p.kind==='airport'){shape=`<circle r="${p.kind==='airport'?5:5.5}" fill="${isMissed?'#abb9a3':'#fffefa'}" stroke="${isMissed?'#97a891':r.color}" stroke-width="2"/>`}
 else if(hkeys.includes(k)||isMissed){shape=markerShape(p.kind,cls.color,isMissed)}else{shape=`<circle r="3" fill="#fbfcf5" stroke="#8da18e" stroke-width="1.2"/>`}
 const title=`${p.name}${p.remote?' · 峰顶/远观目标':' · 约'+fmt(p.alt)+'米'}${isMissed?' · 未包含':''}`;
 const markup=`<g class="point-hit" data-point="${k}" tabindex="0" role="button" aria-label="${esc(title)}" transform="translate(${a[0].toFixed(1)},${a[1].toFixed(1)})" opacity="${opacity}"><title>${esc(title)}</title><circle r="17" fill="transparent"/>${shape}</g>`;if(primary)primaryShapes+=markup;else shapes+=markup;
 if(!state.labels||(d&&!selected&&!isMissed))return;let name=p.name.replace('观景方向','').replace('方向','').replace('／扎西半岛','').replace('／派镇段','').replace('／即乌','').replace('／珠峰观景','').replace('／八一','').replace('一带','').replace('沿线','');if(state.mode==='compare'&&cam.z<6&&!primary&&name.length>6)name=name.slice(0,6);const tw=Math.min(name.length*10.2,130),th=16;
 const opts=primary?[[18,-17],[-tw/2,-21],[17,22],[-tw-16,4]]:[[16,-4],[-tw-16,-4],[-tw/2,27],[-tw/2,-19]];let pos=null;
 for(const [dx,dy]of opts){const box=[a[0]+dx,a[1]+dy-12,tw,th];if(box[0]<4||box[0]+tw>size.w-5||box[1]<46||box[1]+th>size.h-85)continue;if(!accepted.some(b=>box[0]<b[0]+b[2]+5&&box[0]+box[2]+5>b[0]&&box[1]<b[1]+b[3]+3&&box[1]+box[3]+3>b[1])){pos=[dx,dy];accepted.push(box);break}}
 if(!pos&&primary)pos=[16,-17];if(pos)labels+=`<text class="map-label ${primary?'primary':''} ${isMissed?'missed':''}" x="${(a[0]+pos[0]).toFixed(1)}" y="${(a[1]+pos[1]).toFixed(1)}" opacity="${opacity}" pointer-events="none">${esc(name)}</text>`;
 });return shapes+primaryShapes+labels}
function renderRoads(){const list=visibleRoutes();let out='';const sel=route(),d=selectedDay();for(const r of list){let keys=r.days.flatMap(t=>t.keys);const path=pathFor(keys);let opacity=state.day!==null?.14:(state.mode==='compare'?(r.id===sel.id?.93:.7):.94);out+=`<path d="${path}" fill="none" stroke="#fffef7" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" opacity="${opacity*.85}" pointer-events="none"/><path class="map-road" data-maproute="${r.id}" d="${path}" fill="none" stroke="${r.color}" stroke-width="${r.id===sel.id?4:3}" stroke-linecap="round" stroke-linejoin="round" opacity="${opacity}" ${state.mode==='compare'&&r.id!==sel.id?'stroke-dasharray="10 3"':''}><title>${esc(r.name)}</title></path>`}
 if(d&&d.keys.length>1){const path=pathFor(d.keys);out+=`<path d="${path}" fill="none" stroke="#fffef7" stroke-width="10" stroke-linejoin="round" stroke-linecap="round"/><path d="${path}" fill="none" stroke="${sel.color}" stroke-width="5" stroke-linejoin="round" stroke-linecap="round" ${d.tag==='条件徒步'?'stroke-dasharray="6 5"':''}/>`;
  let longest=null;for(let i=1;i<d.keys.length;i++){const a=xy(d.keys[i-1]),b=xy(d.keys[i]),dist=Math.hypot(b[0]-a[0],b[1]-a[1]);if(!longest||dist>longest.dist)longest={a,b,dist}}
  if(longest&&longest.dist>40){const {a,b}=longest,m=[a[0]*.45+b[0]*.55,a[1]*.45+b[1]*.55],ang=Math.atan2(b[1]-a[1],b[0]-a[0])*180/Math.PI;out+=`<g transform="translate(${m[0]},${m[1]}) rotate(${ang})"><path d="m-5-6 8 6-8 6" fill="none" stroke="#fffefa" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></g>`}
 }
 return out}
function renderMap(){const rct=$('mapPanel').getBoundingClientRect();if(rct.width<10)return;size.w=rct.width;size.h=rct.height;$('mapSvg').setAttribute('viewBox',`0 0 ${size.w} ${size.h}`);
 $('mapSvg').innerHTML=`<defs><radialGradient id="landTint"><stop offset="0%" stop-color="#d6e6d0" stop-opacity=".65"/><stop offset="100%" stop-color="#eef1e6" stop-opacity="0"/></radialGradient><radialGradient id="westTint"><stop offset="0%" stop-color="#e8dbbf" stop-opacity=".65"/><stop offset="100%" stop-color="#eef1e6" stop-opacity="0"/></radialGradient></defs>${!state.online&&!isOfficialMap()?`<rect width="100%" height="100%" fill="#edf0e6"/><ellipse cx="${size.w*.84}" cy="${size.h*.72}" rx="${size.w*.7}" ry="${size.h*.9}" fill="url(#landTint)"/><ellipse cx="${size.w*.15}" cy="${size.h*.17}" rx="${size.w*.7}" ry="${size.h*.7}" fill="url(#westTint)"/>`:''}${!isOfficialMap()?`<g ${state.online?'opacity=".15"':''}>${renderGrid()}</g>${!state.online?renderRegions():''}`:''}<g>${renderRoads()}</g><g>${drawPoints()}</g>`;
 renderScale();renderTiles();if(popupKey)positionPopup(popupKey)
}
function renderScale(){const [,lat]=inv(cam.x,cam.y),mpp=isOfficialMap()&&sdkScale&&Number.isFinite(sdkScale.mpp)&&sdkScale.mpp>0?sdkScale.mpp:40075016.686*Math.cos(lat*Math.PI/180)/world(),target=mpp*70/1000,base=Math.pow(10,Math.floor(Math.log10(target))),v=target/base,km=(v>=5?5:v>=2?2:1)*base;$('scaleText').textContent=`${fmt(km)} km`;$('scaleLine').style.width=(km*1000/mpp)+'px'}
const tileNodes=new Map();let tileWarned=false;
function renderTiles(){if(isOfficialMap()){$('tiles').innerHTML='';tileNodes.clear();$('attribution').textContent=(state.basemap==='amap'?'GCJ-02':'BD-09')+' · 官方坐标转换';return}if(!state.online){$('tiles').innerHTML='';tileNodes.clear();$('attribution').textContent='WGS84 · 地理示意';return}
 const z=Math.max(0,Math.floor(cam.z)),n=2**z,sz=256*2**(cam.z-z),left=cam.x*n-size.w/(2*sz),top=cam.y*n-size.h/(2*sz);const needed=new Set();
 for(let y=Math.floor(top);y<=Math.floor(top+size.h/sz);y++)for(let x=Math.floor(left);x<=Math.floor(left+size.w/sz);x++){if(y<0||y>=n)continue;const xx=((x%n)+n)%n,key=`${z}/${xx}/${y}`;needed.add(key);let img=tileNodes.get(key);if(!img){img=new Image();img.alt='';img.decoding='async';img.referrerPolicy='strict-origin-when-cross-origin';img.draggable=false;img.onload=()=>{if(state.basemap!=='osm'||tileNodes.get(key)!==img)return;tileCount++;img.style.visibility='visible';};img.onerror=()=>{if(state.basemap!=='osm'||tileNodes.get(key)!==img)return;tileFailures++;img.style.visibility='hidden';if(!tileWarned){tileWarned=true;mapNotice('部分 OpenStreetMap 瓦片未能加载；可在地图设置中选择离线示意底图。',true)}};img.src=`https://tile.openstreetmap.org/${key}.png`;tileNodes.set(key,img);$('tiles').appendChild(img)}img.style.left=(x-left)*sz+'px';img.style.top=(y-top)*sz+'px';img.style.width=sz+.2+'px';img.style.height=sz+.2+'px'}
 for(const [key,img]of tileNodes){if(!needed.has(key)){img.remove();tileNodes.delete(key)}}
 $('attribution').innerHTML='<a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">© OpenStreetMap</a>'
}
function hidePopup(){popupKey=null;$('pointPopup').style.display='none'}
function showPopup(k){if(!P[k])return;popupKey=k;const p=P[k],r=route(),ds=r.days.filter(d=>d.keys.includes(k)||d.highlights.includes(k)),inRoute=ds.length>0;
 $('pointPopup').innerHTML=`<button class="pop-close" id="closePopup" aria-label="关闭地点详情">${icon('close',16)}</button><div class="eyebrow" style="color:${CATS[p.kind].color}">${CATS[p.kind].name}${inRoute?'':' · 本线未包含'}</div><h3>${esc(p.name)}</h3><div class="pop-meta">${p.remote?'峰顶参考':'地点参考'}海拔约 ${fmt(p.alt)} m${p.remote?' · 不计入行车海拔':''}</div><p>${esc(p.desc||'城镇／公路经由点。坐标和海拔为区域参考，具体住宿和入口需另核。')}</p><div class="pop-meta" style="margin-top:7px">粗定位 ${p.lat.toFixed(2)}°N / ${p.lon.toFixed(2)}°E · 非导航入口</div>${inRoute?`<div class="pop-actions">${ds.map(d=>`<button data-day="${d.day-1}">D${d.day} ${shortDate(d.date)}</button>`).join('')}</div>`:''}`;$('pointPopup').style.display='block';positionPopup(k)
}
function positionPopup(k){const [x,y]=xy(k),box=$('pointPopup'),w=box.offsetWidth||246,h=box.offsetHeight||210;box.style.left=Math.min(size.w-w/2-8,Math.max(w/2+8,x))+'px';box.style.top=Math.max(h+8,Math.min(size.h-65,y-18))+'px'}
function focusPoint(k,isMissed=false){stopPlay();if(isMissed){state.missed=true;$('missedToggle').checked=true}state.highlight=true;$('highlightToggle').checked=true;state.hiddenCats.delete(P[k].kind);if(isOfficialMap()){sendSDK('focus',{key:k});renderLegend();requestMap();showPopup(k);if(window.innerWidth<950)$('mapPanel').scrollIntoView({behavior:'smooth',block:'center'});return}const q=merc(P[k].lon,P[k].lat);cam.x=q[0];cam.y=q[1]-.00025;cam.z=Math.min(10,Math.max(cam.z,7.7));renderLegend();requestMap();showPopup(k);if(window.innerWidth<950)$('mapPanel').scrollIntoView({behavior:'smooth',block:'center'})}

// Profile: actual samples are discrete planning references, never a fabricated DEM curve.
function chartTooltip(text,x,y){const t=$('chartTooltip');t.textContent=text;t.style.display='block';t.style.left=Math.min(window.innerWidth-225,x+10)+'px';t.style.top=Math.max(10,y-42)+'px'}
function renderChart(){const r=route(),d=selectedDay(),el=$('profileSvg'),w=Math.max(280,el.getBoundingClientRect().width||600),h=window.innerWidth>1650?146:window.innerWidth<540?117:window.innerWidth<1251&&window.innerWidth>950?106:120;el.setAttribute('viewBox',`0 0 ${w} ${h}`);let mode=state.chart;if(mode==='daily'&&!d){mode='sleep';state.chart='sleep'}
 $('sleepChartBtn').classList.toggle('active',mode==='sleep');$('dailyChartBtn').classList.toggle('active',mode==='daily');$('driveChartBtn').classList.toggle('active',mode==='drive');
 const pad={l:38,r:15,t:21,b:26},iw=w-pad.l-pad.r,ih=h-pad.t-pad.b;let out='',points=[],min=0,max=0;
 if(mode==='drive'){
  $('chartTitle').textContent='12天净驾驶时间';$('chartFoot').textContent='柱顶为上下限；不含拍照、餐饮、加油、检查、接驳等候。';$('chartFootRight').textContent='点击柱子查看当天';
  max=Math.max(...r.days.map(v=>v.hours[1]),8);const yy=v=>pad.t+ih-(v/max)*ih;for(let v=0;v<=max;v+=2){const y=yy(v);out+=`<path d="M${pad.l} ${y}H${w-pad.r}" stroke="#e3e8dd" stroke-width=".8"/><text x="${pad.l-7}" y="${y+3}" text-anchor="end" class="chart-axis">${v}h</text>`}
  const slot=iw/12,bw=Math.max(6,slot*.5);r.days.forEach((v,i)=>{const x=pad.l+slot*(i+.5),y=yy(v.hours[1]),y0=yy(v.hours[0]);out+=`<g class="chart-hit" data-chart-day="${i}" data-tip="D${i+1} ${shortDate(v.date)} · 净驾驶 ${range(v.hours)} 小时"><title>D${i+1} ${range(v.hours)}小时</title><rect x="${x-bw/2-4}" y="${pad.t-6}" width="${bw+8}" height="${ih+30}" fill="transparent"/><rect x="${x-bw/2}" y="${y}" width="${bw}" height="${yy(0)-y}" rx="3" fill="${r.color}" opacity="${state.day===null||state.day===i?.76:.24}"/><rect x="${x-bw/2}" y="${y0}" width="${bw}" height="${Math.max(0,yy(0)-y0)}" rx="2" fill="${r.color}" opacity="${state.day===null||state.day===i?.9:.3}"/><text x="${x}" y="${y-5}" text-anchor="middle" class="chart-number" style="fill:${state.day===i?r.color:'#6e8475'}">${fmt(v.hours[1])}</text><text x="${x}" y="${h-8}" text-anchor="middle" class="chart-label">D${i+1}</text></g>`});el.innerHTML=out;return;
 }
 if(mode==='sleep'){
  $('chartTitle').textContent='每晚住宿海拔';$('chartFoot').textContent='11晚参考海拔。D12离藏，不画成海拔归零；点击日期联动。';$('chartFootRight').textContent='不含山峰高度 / 飞行高度';points=r.days.filter(v=>v.sleepAlt!==null).map((v,i)=>({label:'D'+v.day,value:v.sleepAlt,detail:`D${v.day} ${P[v.sleep].name} · 约${fmt(v.sleepAlt)} m`,day:i}));
 }else{
  $('chartTitle').textContent=`D${d.day} · 当天关键点海拔`;$('chartFoot').textContent='经由点等距排列，不代表实际里程比例；虚线连接参考值。';$('chartFootRight').textContent='不是连续GPS/DEM剖面';points=d.profile.map((p,i)=>({label:p[0].replace('观景方向','').replace('方向','').replace('一带',''),value:p[1],detail:`${p[0]} · 约${fmt(p[1])} m`,day:null}));
 }
 min=Math.floor((Math.min(...points.map(p=>p.value))-150)/500)*500;max=Math.ceil((Math.max(...points.map(p=>p.value))+150)/500)*500;if(max-min<800){min-=500;max+=500}const yy=v=>pad.t+(max-v)/(max-min)*ih;const step=max-min>2200?1000:500;
 if(max>=4500&&min<4500){const y=yy(4500);out+=`<rect x="${pad.l}" y="${pad.t}" width="${iw}" height="${Math.max(0,y-pad.t)}" fill="#f7ead4" opacity=".46"/><text x="${w-pad.r}" y="${Math.min(y-3,pad.t+9)}" text-anchor="end" class="chart-axis" style="fill:#b0986b">4500m 参考线 · 非安全界线</text>`}
 for(let v=Math.ceil(min/step)*step;v<=max;v+=step){const y=yy(v);out+=`<path d="M${pad.l} ${y}H${w-pad.r}" stroke="#e1e7dc" stroke-width=".8" ${v===4500?'stroke-dasharray="4 3"':''}/><text x="${pad.l-7}" y="${y+3}" text-anchor="end" class="chart-axis">${v}</text>`}
 const xx=i=>pad.l+iw*(points.length===1?.5:i/(points.length-1));const path=points.map((p,i)=>`${i?'L':'M'}${xx(i)},${yy(p.value)}`).join(' ');out+=`<path d="${path} L${xx(points.length-1)} ${pad.t+ih} L${xx(0)} ${pad.t+ih}Z" fill="${r.color}" opacity=".055"/><path d="${path}" fill="none" stroke="${r.color}" stroke-width="2" stroke-dasharray="${mode==='daily'?'4 4':'none'}"/>`;
 points.forEach((p,i)=>{const x=xx(i),y=yy(p.value),sel=mode==='daily'||state.day===i,showNumber=w>480||points.length<=6||i%2===0||i===points.length-1;let label=p.label;if(mode==='daily'&&label.length>5)label=label.slice(0,5);const widthSlot=iw/Math.max(1,points.length-1);const showLabel=mode==='sleep'||points.length<=7||i%2===0||i===points.length-1;out+=`<g class="chart-hit" ${p.day===null?'':`data-chart-day="${p.day}"`} data-tip="${esc(p.detail)}"><title>${esc(p.detail)}</title><circle cx="${x}" cy="${y}" r="13" fill="transparent"/><circle cx="${x}" cy="${y}" r="${sel?4.8:3.4}" fill="${sel?r.color:'#fffefa'}" stroke="${r.color}" stroke-width="1.8"/>${showNumber?`<text x="${x}" y="${y-9}" text-anchor="middle" class="chart-number" style="font-size:${w<440?8:9}px">${fmt(p.value)}</text>`:''}${showLabel?`<text x="${x}" y="${h-8}" text-anchor="middle" class="chart-label" style="font-size:${mode==='daily'?8:9}px">${esc(label)}</text>`:''}</g>`});el.innerHTML=out
}
function updatePlayIcon(){$('playBtn').innerHTML=icon(state.playing?'pause':'play');$('playBtn').classList.toggle('active',state.playing);$('playBtn').title=state.playing?'暂停播放':'逐日播放';$('playBtn').setAttribute('aria-label',$('playBtn').title)}
function stopPlay(){state.playing=false;if(playTimer)clearInterval(playTimer);playTimer=null;updatePlayIcon()}
function startPlay(){if(state.playing){stopPlay();return}state.playing=true;let i=state.day===null||state.day>=11?0:state.day;selectDay(i,true);updatePlayIcon();playTimer=setInterval(()=>{if(state.day>=11){stopPlay();return}selectDay(state.day+1,true);updatePlayIcon()},2800)}

function fillSources(){let intro=`<p>本页为 <strong>2026/12/25—2027/1/5，12天11晚</strong> 的旅行规划原型。资料核对至 <strong>${DATA.meta.asOf}</strong>；没有实时路况、酒店库存、航空班表或景区开放接口。</p><div class="readme-box"><strong>地图不是导航轨迹</strong><p>线条连接约略WGS84经由点，便于比较路线方向；不是沿真实道路贴合的轨迹，也不指示穿越湖泊、山脉或非道路区域。OpenStreetMap、高德和百度街道底图只提供背景，不能让示意线变成导航路线。国内底图中的景点与线路位置先通过对应官方服务转换坐标；原始行程数据保留WGS84参考坐标。景点与村落坐标是粗定位，需在实际导航中重新核实入口。</p></div><div class="readme-box"><strong>两种海拔，不要混为一谈</strong><p>“住宿海拔”连接11个夜间住宿参考值；D12离藏不计住宿。“当天关键点”是经由点等距排列，不是按里程采样的DEM曲线，未标注的垭口可能更高。冈仁波齐、南迦巴瓦、珠峰的峰顶高度只出现在远观目标弹窗，绝不混入行车曲线。4500m只作图表对照，不是安全分界线。</p></div><div class="readme-box"><strong>时间、公里数与缓冲的口径</strong><p>里程与净驾驶时长均为人工规划区间，含机场接驳和市内粗估，不包含飞机里程；没有调用导航API测量，未按实时冬季通行速度计算。吃饭、加油、拍照、检查、接驳等候另加。步行／景区活动时长另列。1月4日标为“条件性缓冲”时，如被前段延误占用，就不能同时保证拉萨第二整天。A2没有这个末段缓冲。</p></div><div class="readme-box"><strong>冬季必须再次核实</strong><p>道路与景区可能临时管制；各住宿点需确认实际营业、供暖、热水和餐饮。冈仁波齐完整转山未排入；白玛林措徒步为可取消选项；墨脱按历史偶进奇出规则预排12/28进、12/31出，实际应遵守当期公告。所有方案都未默认进入冰面。按各人证件类别确认边境通行手续；不能只凭行程表出行。</p></div><h3>离线与在线使用</h3><p>路线切换、地理示意图、拖动缩放、景点弹窗、每日海拔图、行车图、对比表和CSV导出均可离线使用。默认的OpenStreetMap街道底图无需Key，会请求当前视图瓦片，并把视图位置与网络信息提供给该服务；本页不请求定位权限。没有网络或底图加载失败时自动退回离线示意底图。高德与百度仅在填入自己的Key并主动启用后加载官方JS SDK及坐标转换服务；Key设置、授权与计费说明见“地图设置”。地图切换不改变行程、海拔或驾驶时长的人工规划口径。</p><h3>参考来源</h3><p>旧公告仅用于识别规则和风险，不等于确认本次日期开放。下列来源不为本页每条时间估计提供实时测量背书。</p>`;
 $('sourcesBody').innerHTML=intro+`<div class="sources-grid">${DATA.sources.map(s=>`<article class="source-card" id="source-${s.id}"><div class="source-label">${s.id} · ${esc(s.date)}</div><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.title)} ↗</a><p>${esc(s.scope)}</p></article>`).join('')}</div>`}
function fillCompare(){$('compareBody').innerHTML=`<p>统一口径：全部为12天11晚。海拔比较看的是<strong>夜间住宿</strong>，不是途经山口或远观雪峰；公路时间均为估计。</p><div class="table-wrap" style="margin-top:15px"><table class="compare-table"><thead><tr><th>方案</th><th>公路里程估计</th><th>净驾驶合计</th><th>最高住宿</th><th>≥4500m夜数</th><th>末段缓冲</th><th></th></tr></thead><tbody>${R.map(r=>`<tr><td><div class="table-route"><i style="background:${r.color}"></i>${r.code} ${esc(r.name)}</div><div style="font-size:10px;color:var(--muted);margin-top:5px;max-width:220px">${esc(r.subtitle)}</div></td><td class="num">${range(r.stats.km)} km</td><td class="num">${range(r.stats.hours)} h</td><td class="num">${fmt(r.stats.maxSleep)} m</td><td>${r.stats.highNights} 晚</td><td>${r.buffer?'1天，挤占拉萨游览':'没有'}</td><td><button class="table-select" data-choose="${r.id}">查看</button></td></tr>`).join('')}</tbody></table></div><p class="table-explainer">公里数接近，不代表景观重复程度或道路难度相同。南线往返重复路段多；墨脱里程较短却需要较长驾驶时间；林芝—然乌也包含住宿海拔明显上升。</p><h3>每条路线最重要的取舍</h3><div class="sources-grid">${R.map(r=>`<div class="source-card"><a href="#" data-choose="${r.id}" style="color:${r.color}">${r.code} · ${esc(r.name)}</a><p>${esc(r.tradeoff)}</p></div>`).join('')}</div>`}
function showSources(id=null){$('sourcesDialog').showModal();if(id)setTimeout(()=>{const el=$('source-'+id);if(el){el.scrollIntoView({block:'center',behavior:'smooth'});el.style.borderColor=route().color;setTimeout(()=>el.style.borderColor='',2500)}},80)}
function exportCSV(){const r=route(),headers=['日期','天数','行程','起点','终点','住宿','住宿海拔_约米','较前夜变化_约米','公路里程下限_km','公路里程上限_km','净驾驶下限_h','净驾驶上限_h','步行或景区活动_h','参考道路','提示','参考来源','数据性质'];let rows=[headers];r.days.forEach(d=>rows.push([d.date,d.day,d.title,P[d.start].name,P[d.end].name,d.sleep?P[d.sleep].name:'离藏',d.sleepAlt??'',d.sleepChange??'',...d.km,...d.hours,d.walk?range(d.walk):'',d.road,d.note,d.refs.map(id=>DATA.sources.find(s=>s.id===id)?.url||id).join(' | '),'人工规划区间；地图为经由点示意；非实时导航、非开放确认']));const csv='\uFEFF'+rows.map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'})),a=document.createElement('a');a.href=url;a.download=`西藏行程_${r.code}_20261225-20270105.csv`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);notify('已导出当前路线的12天行程CSV。')}

// Event wiring. All controls are native buttons or accessible keyboard targets.
document.addEventListener('click',e=>{const t=e.target.closest('[data-day],[data-route],[data-focus],[data-source],[data-choose],[data-close],[data-cat]');if(!t)return;if(e.target.matches('[data-overlay]'))return;
 if(t.dataset.day!==undefined){selectDay(Number(t.dataset.day));return}
 if(t.dataset.route){selectRoute(t.dataset.route);return}
 if(t.dataset.focus){focusPoint(t.dataset.focus,t.dataset.missed==='true');return}
 if(t.dataset.source){showSources(t.dataset.source);return}
 if(t.dataset.choose){e.preventDefault();$('compareDialog').close();state.filter='all';document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter==='all'));selectRoute(t.dataset.choose);return}
 if(t.dataset.close){$(t.dataset.close).close();return}
 if(t.dataset.cat){const c=t.dataset.cat;if(state.hiddenCats.has(c))state.hiddenCats.delete(c);else state.hiddenCats.add(c);renderLegend();requestMap();return}
});
$('routeList').addEventListener('change',e=>{const id=e.target.dataset.overlay;if(!id)return;if(e.target.checked)state.checked.add(id);else state.checked.delete(id);renderMapHeader();fitCurrent()});
$('routeList').addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.dataset.route){e.preventDefault();selectRoute(e.target.dataset.route)}});
document.querySelectorAll('[data-filter]').forEach(b=>b.addEventListener('click',()=>{state.filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(q=>q.classList.toggle('active',q===b));if(!isVisibleRoute(route())){state.route=R.find(isVisibleRoute).id;state.day=null;state.chart='sleep'}updateAll(true);saveHash()}));
$('singleMode').onclick=()=>{state.mode='single';updateAll(true);saveHash()};$('compareMode').onclick=()=>{state.mode='compare';state.day=null;state.chart='sleep';if(!state.checked.size)state.checked.add(state.route);updateAll(true);saveHash()};
$('overviewBtn').onclick=overview;$('fitBtn').onclick=fitCurrent;$('zoomIn').onclick=()=>zoomBy(.7);$('zoomOut').onclick=()=>zoomBy(-.7);
$('highlightToggle').onchange=e=>{state.highlight=e.target.checked;requestMap()};$('labelToggle').onchange=e=>{state.labels=e.target.checked;requestMap()};$('missedToggle').onchange=e=>{state.missed=e.target.checked;fitCurrent()};
// Basemap controls are wired by initializeMapSettings().
$('prevDay').onclick=()=>selectDay(state.day===null?0:Math.max(0,state.day-1));$('nextDay').onclick=()=>selectDay(state.day===null?0:Math.min(11,state.day+1));$('playBtn').onclick=startPlay;
$('sleepChartBtn').onclick=()=>{state.chart='sleep';renderChart()};$('dailyChartBtn').onclick=()=>{state.chart='daily';if(state.day===null)selectDay(0);else renderChart()};$('driveChartBtn').onclick=()=>{state.chart='drive';renderChart()};
$('itineraryTab').onclick=()=>{state.tab='itinerary';renderRight()};$('tradeoffTab').onclick=()=>{state.tab='tradeoff';renderRight()};$('rightContent').addEventListener('click',e=>{if(e.target.id==='backAll')overview()});
$('sourcesBtn').onclick=()=>showSources();$('methodBtn').onclick=()=>showSources();$('compareTableBtn').onclick=()=>{$('compareDialog').showModal()};$('exportBtn').onclick=exportCSV;
$('profileSvg').addEventListener('click',e=>{const a=e.target.closest('[data-chart-day]');if(a)selectDay(Number(a.dataset.chartDay))});$('profileSvg').addEventListener('mousemove',e=>{const t=e.target.closest('[data-tip]');if(t)chartTooltip(t.dataset.tip,e.clientX,e.clientY);else $('chartTooltip').style.display='none'});$('profileSvg').addEventListener('mouseleave',()=>$('chartTooltip').style.display='none');
$('pointPopup').addEventListener('click',e=>{if(e.target.closest('#closePopup'))hidePopup()});
// Mouse, touch drag, pinch, wheel and double-click navigation.
const pointers=new Map();let gesture=null,moved=false,lastGestureEnd=0,downHit=null;
function local(e){const b=$('mapStage').getBoundingClientRect();return [e.clientX-b.left,e.clientY-b.top]}
function startGesture(){const arr=[...pointers.values()];if(arr.length>=2){const a=arr[0],b=arr[1];gesture={type:'pinch',dist:Math.hypot(b[0]-a[0],b[1]-a[1]),z:cam.z,x:cam.x,y:cam.y,mid:[(a[0]+b[0])/2,(a[1]+b[1])/2]}}else if(arr.length===1)gesture={type:'pan',start:arr[0],x:cam.x,y:cam.y,z:cam.z}}
$('mapStage').addEventListener('pointerdown',e=>{if(isOfficialMap())return;if(e.button!==undefined&&e.button!==0)return;pointers.set(e.pointerId,local(e));downHit={point:e.target.closest('[data-point]')?.dataset.point,route:e.target.closest('[data-maproute]')?.dataset.maproute};moved=false;startGesture();try{$('mapStage').setPointerCapture(e.pointerId)}catch(_){} });
$('mapStage').addEventListener('pointermove',e=>{if(isOfficialMap())return;if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,local(e));const arr=[...pointers.values()];if(gesture?.type==='pinch'&&arr.length>=2){const a=arr[0],b=arr[1],dist=Math.hypot(b[0]-a[0],b[1]-a[1]),mid=[(a[0]+b[0])/2,(a[1]+b[1])/2];cam.z=Math.max(4,Math.min(13,gesture.z+Math.log2(Math.max(1,dist)/Math.max(1,gesture.dist))));const oldS=256*2**gesture.z;const wx=gesture.x+(gesture.mid[0]-size.w/2)/oldS,wy=gesture.y+(gesture.mid[1]-size.h/2)/oldS;cam.x=wx-(mid[0]-size.w/2)/world();cam.y=wy-(mid[1]-size.h/2)/world();moved=true;hidePopup();requestMap()}else if(gesture?.type==='pan'&&arr.length){const a=arr[0],dx=a[0]-gesture.start[0],dy=a[1]-gesture.start[1];if(Math.hypot(dx,dy)>3){moved=true;$('mapStage').classList.add('dragging');cam.x=gesture.x-dx/world();cam.y=gesture.y-dy/world();hidePopup();requestMap()}}});
function pointerUp(e){if(isOfficialMap())return;pointers.delete(e.pointerId);if(pointers.size)startGesture();else{gesture=null;$('mapStage').classList.remove('dragging');if(moved){lastGestureEnd=Date.now()}else if(downHit?.point){showPopup(downHit.point);lastGestureEnd=Date.now()}else if(downHit?.route&&state.mode==='compare'){selectRoute(downHit.route);lastGestureEnd=Date.now()}downHit=null;}}
$('mapStage').addEventListener('pointerup',pointerUp);$('mapStage').addEventListener('pointercancel',pointerUp);
$('mapStage').addEventListener('wheel',e=>{if(isOfficialMap())return;e.preventDefault();zoomBy(e.deltaY>0?-.25:.25,local(e))},{passive:false});
$('mapStage').addEventListener('dblclick',e=>{if(isOfficialMap())return;if(!e.target.closest('[data-point]'))zoomBy(.8,local(e))});
$('mapStage').addEventListener('click',e=>{if(!isOfficialMap()&&(Date.now()-lastGestureEnd<200||moved))return;const t=e.target.closest('[data-point]');if(t){showPopup(t.dataset.point);return}const p=e.target.closest('[data-maproute]');if(p&&state.mode==='compare'){selectRoute(p.dataset.maproute);return}hidePopup()});
$('mapSvg').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.dataset.point){e.preventDefault();showPopup(e.target.dataset.point)}});
for(const id of ['sourcesDialog','compareDialog','mapSettingsDialog']){$(id).addEventListener('click',e=>{if(e.target===$(id)){const rect=$(id).getBoundingClientRect();if(e.clientX<rect.left||e.clientX>rect.right||e.clientY<rect.top||e.clientY>rect.bottom)$(id).close()}})}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){hidePopup();stopPlay()}if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)||$('sourcesDialog').open||$('compareDialog').open||$('mapSettingsDialog').open)return;if(e.key==='ArrowRight'){e.preventDefault();selectDay(state.day===null?0:Math.min(11,state.day+1))}if(e.key==='ArrowLeft'){e.preventDefault();selectDay(state.day===null?0:Math.max(0,state.day-1))}});
let resizeTimer;const ro=new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{const b=$('mapPanel').getBoundingClientRect();size.w=b.width;size.h=b.height;renderChart();requestMap()},70)});ro.observe($('mapPanel'));ro.observe($('profileSvg'));
// A shareable hash restores the selected route/day without cookies or an account.
try{const h=new URLSearchParams(location.hash.slice(1));if(R.some(r=>r.id===h.get('route')))state.route=h.get('route');const dd=Number(h.get('day'));if(dd>=1&&dd<=12)state.day=dd-1;if(h.get('mode')==='compare')state.mode='compare';if(state.day!==null)state.chart='daily'}catch(_){}
fillIcons();fillSources();fillCompare();const b=$('mapPanel').getBoundingClientRect();size.w=b.width;size.h=b.height;updateAll(true);saveHash();initializeMapSettings();
window.TibetRouteLab={DATA,state,selectRoute,selectDay,overview,fitCurrent,exportCSV,activateBasemap,openMapSettings};
